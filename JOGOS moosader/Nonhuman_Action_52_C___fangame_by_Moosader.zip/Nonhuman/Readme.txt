"Nonhuman" Action 52 fan game
by Rachel J. Morris


CONTROLS

You can use either WASD to move or the arrow keys.

Space, Up, and Right Mouse jumps.

Left mouse button fires lasers, moving the mouse aims.

ESC or F4 quits.


GAMEPLAY

There are three levels-- in each you need to
collect the key and head to the door.
On the way, you can kill the robot enemies with
your lazors.


HEADS-UP DISPLAY
There are seven stars in the upper-left of the screen,
this denotes how many of the robots you have killed
in the level.  At the moment, nothing special happens
if you kill all of them in a level.

To the upper-right is your lives count.


CREDITS

Programming - Rachel J. Morris
Graphics - From Action 52 (NES) by Active Enterprises, and also by Rachel J. Morris
Music - From Action 52
Sound - From Ascii's RPG Maker 2000

Game was made in C++ with the Allegro Game Programming library





