#include "ImageManager.h"

ImageManager::ImageManager()
{
    buffer = create_bitmap( 640, 480 );
    potato[0].Setup( "background" );
    potato[1].Setup( "jitensha" );
    potato[2].Setup( "nomi" );
    potato[3].Setup( "sakana" );
    potato[4].Setup( "toire" );
    potato[5].Setup( "gptitle" );
    potato[6].Setup( "goat" );
}

ImageManager::~ImageManager()
{
    if ( buffer != NULL )
        destroy_bitmap( buffer );
        
    for ( int i=0; i<IMGAMT; i++ )
    {
        if ( potato[i].img != NULL )
            destroy_bitmap( potato[i].img );
    }
}

void ImageManager::Draw( string name, int x, int y, int w, int h, int fx, int fy )
{
    bool success = false;
    for ( int i=0; i<IMGAMT; i++ )
    {
        if ( potato[i].description == name )
        {
            Draw( i, x, y, w, h, fx, fy );
            success = true;
        }
    }
    if ( !success ) { cerr<<"Error drawing "<<name<<endl; }
}

void ImageManager::Draw( int index, int x, int y, int w, int h, int fx, int fy )
{
    masked_blit( potato[index].img, buffer, fx, fy, x, y, w, h );
}


