#include "Gui.h"

Gui::Gui()
{
}

void Gui::Draw( BITMAP *buffer )
{
}

