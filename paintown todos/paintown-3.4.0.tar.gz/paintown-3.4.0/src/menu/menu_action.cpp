#include "menu/menu_action.h"

MenuAction::MenuAction()
{
}

MenuAction::~MenuAction()
{
	// Nothing
}


