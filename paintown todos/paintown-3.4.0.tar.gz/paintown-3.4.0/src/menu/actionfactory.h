#ifndef _paintown_actionfactory_h
#define _paintown_actionfactory_h

class Token;

void ActionAct(Token *token);

#endif

