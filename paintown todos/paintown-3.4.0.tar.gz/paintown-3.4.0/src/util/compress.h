#ifndef _paintown_compress_h
#define _paintown_compress_h

namespace Compress{
    void testCompression(unsigned char * data, int length);
}

#endif
