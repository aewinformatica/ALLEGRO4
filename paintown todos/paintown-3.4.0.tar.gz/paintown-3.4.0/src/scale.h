#ifndef _scale_h
#define _scale_h

void scale2x_allegro( BITMAP * src_bitmap, BITMAP * dest_bitmap, unsigned int pixel );

void scale4x_allegro( BITMAP * src_bitmap, BITMAP * dest_bitmap, unsigned int pixel );

#endif
