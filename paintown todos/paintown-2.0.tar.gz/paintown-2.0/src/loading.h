#ifndef _loading_h
#define _loading_h

void * loadingScreen( void * arg );

#endif
