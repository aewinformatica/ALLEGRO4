#ifndef _paintown_main_h
#define _paintown_main_h

int paintown_main( int argc, char ** argv );

#endif
