#!/bin/sh

java -jar editor.jar -client
