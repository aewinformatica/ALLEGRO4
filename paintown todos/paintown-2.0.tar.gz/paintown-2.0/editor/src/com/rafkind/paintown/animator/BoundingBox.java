package com.rafkind.paintown.animator;

import java.util.*;

public class BoundingBox
{
	// Basic character info
	public int x1;
	public int y1;
	public int x2;
	public int y2;
	
	public BoundingBox()
	{
		// Nothing
	}
}
