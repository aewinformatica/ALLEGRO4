#ifndef _collector_h
#define _collector_h

/* this class calls other static classes destroy() methods */
class Collector{
public:
	Collector();
	~Collector();
};

#endif
