#include "animation_event.h"

AnimationEvent::AnimationEvent( ){
}

void AnimationEvent::Interact( Animation * parent ){

}

AnimationEvent::~AnimationEvent(){
}
