#include "heart.h"
#include <iostream>

using namespace std;

Heart::Heart():
alive( true ){
}

Heart::~Heart(){
}
