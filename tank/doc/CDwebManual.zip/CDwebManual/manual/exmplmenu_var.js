	var NoOffFirstLineMenus=7;
	var LowBgColor='white';
	var LowSubBgColor='white';
	var HighBgColor='black';
	var HighSubBgColor='black';
	var FontLowColor='black';
	var FontSubLowColor='black';
	var FontHighColor='white';
	var FontSubHighColor='white';
	var BorderColor='black';
	var BorderSubColor='black';
	var BorderWidth=1;
	var BorderBtwnElmnts=1;
	var FontFamily="arial,comic sans ms,technical";
	var FontSize=8;
	var FontBold=1;
	var FontItalic=0;
	var MenuTextCentered='center';
	var MenuCentered='center';
	var MenuVerticalCentered='top';
	var ChildOverlap=.2;
	var ChildVerticalOverlap=.2;
	var StartTop=20;
	var StartLeft=1;
	var VerCorrect=0;
	var HorCorrect=0;
	var LeftPaddng=3;
	var TopPaddng=2;
	var FirstLineHorizontal=1;
	var MenuFramesVertical=0;
	var DissapearDelay=100;
	var TakeOverBgColor=1;
	var FirstLineFrame='menu';
	var SecLineFrame='main';
	var DocTargetFrame='main';
	var TargetLoc='';
	var HideTop=0;
	var MenuWrap=1;
	var RightToLeft=0;
	var UnfoldsOnClick=0;
	var WebMasterCheck=0;
	var ShowArrow=1;
	var KeepHilite=1;
	var Arrws=['tri.gif',5,10,'tridown.gif',10,5,'trileft.gif',5,10];

function BeforeStart(){return}
function AfterBuild(){return}
function BeforeFirstOpen(){return}
function AfterCloseAll(){return}

Menu1=new Array("Back To Home","javascript:NewWin=window.open('http://www.charreddirt.com','NWin');window['NewWin'].focus()","",0,20,100);
Menu2=new Array("Front Page","cover.htm","",0,20,75);
Menu3=new Array("Story","story.htm","",0,20,50);

Menu4=new Array("Getting Started","gettingstarted.htm#start","",8,20,120);
	Menu4_1=new Array("Installation Requirements","gettingstarted.htm#start0","",0,20,200);
	Menu4_2=new Array("Installation Guide","gettingstarted.htm#start1","",0);
	Menu4_3=new Array("Game Controls","gettingstarted.htm#start2","",0);
	Menu4_4=new Array("Game Options","options.htm#option","",3);
		Menu4_4_1=new Array("Game Options","options.htm#option0","",0,20,110);
		Menu4_4_2=new Array("Sound Options","options.htm#option1","",0);
		Menu4_4_3=new Array("Video Options","options.htm#option2","",0);
	Menu4_5=new Array("Advanced Options","advancedoptions.htm#aoption","",2);
		Menu4_5_1=new Array("Parameter List","advancedoptions.htm#aoption0","",0,20,150);
		Menu4_5_2=new Array("Parameter Combinations","advancedoptions.htm#aoption1","",0);
	Menu4_6=new Array("Game Play","gameplay.htm#play","",4);
		Menu4_6_1=new Array("How To Play","gameplay.htm#play0","",0,20,110);
		Menu4_6_2=new Array("Team Play","gameplay.htm#play1","",0);
		Menu4_6_3=new Array("The H.E.B. System","gameplay.htm#play2","",0);
		Menu4_6_4=new Array("H.E.B. Tips","gameplay.htm#play3","",0);
	Menu4_7=new Array("The Console","console.htm#console","",2);
		Menu4_7_1=new Array("Command List","console.htm#console0","",0,20,100);
		Menu4_7_2=new Array("Variable List","console.htm#console1","",0);
	Menu4_8=new Array("Frequently Asked Questions","faq.htm","",0);

	
Menu5=new Array("Characters","characters.htm","",9);
	Menu5_1=new Array("AI Players","bots.htm#ai","",5,20,90);
		Menu5_1_1=new Array("The Stoopid Bot","bots.htm#ai0","",0,20,100);
		Menu5_1_2=new Array("The Lobber Bot","bots.htm#ai1","",0);
		Menu5_1_3=new Array("The Shooter Bot","bots.htm#ai2","",0);
		Menu5_1_4=new Array("The Gunner Bot","bots.htm#ai3","",0);
		Menu5_1_5=new Array("The Sniper Bot","bots.htm#ai4","",0);
	Menu5_2=new Array("April","april.htm","",0);
	Menu5_3=new Array("Jack","jack.htm","",0);
	Menu5_4=new Array("Lock","lock.htm","",0);
	Menu5_5=new Array("Meshko","meshko.htm","",0);
	Menu5_6=new Array("Mia","mia.htm","",0);
	Menu5_7=new Array("Miki","miki.htm","",0);
	Menu5_8=new Array("Ricky & Marie","rickynmarie.htm","",0);
	Menu5_9=new Array("Saru","saru.htm","",0);
	
	Menu6=new Array("Weapons","weapequip.htm#weapons","",8,20,90);
		Menu6_1=new Array("Weapon Symbols","weapequip.htm#weapons0","",0,20,140);
		Menu6_2=new Array("Conventional Weapons","weapequip.htm#weapons1","",0);
		Menu6_3=new Array("Heat Weapons","weapequip.htm#weapons2","",0);
		Menu6_4=new Array("Energy Weapons","weapequip.htm#weapons3","",0);
		Menu6_5=new Array("Ballistic Weapons","weapequip.htm#weapons4","",0);
		Menu6_6=new Array("Non-Lethal Weapons","weapequip.htm#weapons5","",0);
		Menu6_7=new Array("Super Weapons","weapequip.htm#weapons6","",0);
		Menu6_8=new Array("Equipment","weapequip.htm#weapons7","",2);
			Menu6_8_1=new Array("Defensive Items","weapequip.htm#weapons8","",0,20,120);
			Menu6_8_2=new Array("Special Equipment","weapequip.htm#weapons9","",0);
		Menu7=new Array(" Credit","credit.htm","",0,20,45);
